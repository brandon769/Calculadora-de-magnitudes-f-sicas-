
function generateInputs() {
    const operation = document.getElementById("operation").value;
    const inputDiv = document.getElementById("inputs");
    inputDiv.innerHTML = "";

    const variables = {
        "v=d/t": ["d", "t"],
        "ρ=m/V": ["m", "V"],
        "F=m*a": ["m", "a"],
        "P=W/t": ["W", "t"],
        "a=Δv/t": ["Δv", "t"],
        "p=F/A": ["F", "A"],
        "W=F*d": ["F", "d"],
        "Q=m*c*ΔT": ["m", "c", "ΔT"],
        "V=IR": ["I", "R"],
        "E=V*q": ["V", "q"]
    };

    if (operation && variables[operation]) {
        variables[operation].forEach(variable => {
            const input = document.createElement("input");
            input.type = "number";
            input.placeholder = variable;
            input.id = variable;
            inputDiv.appendChild(input);
        });
    }
}

function calculate() {
    const operation = document.getElementById("operation").value;
    let result = "Resultado: ";
    let res = 0;

    try {
        switch (operation) {
            case "v=d/t":
                res = parseFloat(d.value) / parseFloat(t.value);
                break;
            case "ρ=m/V":
                res = parseFloat(m.value) / parseFloat(V.value);
                break;
            case "F=m*a":
                res = parseFloat(m.value) * parseFloat(a.value);
                break;
            case "P=W/t":
                res = parseFloat(W.value) / parseFloat(t.value);
                break;
            case "a=Δv/t":
                res = parseFloat(Δv.value) / parseFloat(t.value);
                break;
            case "p=F/A":
                res = parseFloat(F.value) / parseFloat(A.value);
                break;
            case "W=F*d":
                res = parseFloat(F.value) * parseFloat(d.value);
                break;
            case "Q=m*c*ΔT":
                res = parseFloat(m.value) * parseFloat(c.value) * parseFloat(ΔT.value);
                break;
            case "V=IR":
                res = parseFloat(I.value) * parseFloat(R.value);
                break;
            case "E=V*q":
                res = parseFloat(V.value) * parseFloat(q.value);
                break;
            default:
                res = "Operación inválida";
        }
    } catch (e) {
        res = "Error en el cálculo";
    }

    document.getElementById("result").innerText = result + res;
}
