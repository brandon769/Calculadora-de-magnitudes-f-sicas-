
# Calculadora de Magnitudes Físicas

Aplicación web para calcular magnitudes físicas como velocidad, densidad, fuerza, etc.

## Autores
- Brandon José Ruidíaz Urrutia
- Leiber Manuel Gomez Urzola

## Cómo usar
1. Selecciona una operación.
2. Ingresa los valores solicitados.
3. Haz clic en "Calcular" para obtener el resultado.

## Tecnologías
- HTML, CSS, JavaScript
